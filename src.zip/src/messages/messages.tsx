import React, { useEffect, useRef, useState } from 'react';
import { User, Send, Paperclip, Smile, MoreVertical } from 'lucide-react';
// import { useAuth } from '../components/AuthContext';
import { supabase } from '../lib/supabaseClient';
import MessageList from './messageList';
import './messages.css';

declare global {
  interface Window {
    handleSelectConversation?: (id: string, name?: string, otherUserId?: string) => void;
  }
}

interface MessagesProps {
  navigateTo: (page: string) => void;
}

interface MessageUI {
  id: string;
  text: string;
  time: string;
  sender: 'user' | 'other';
}

interface MessageData {
  id: string;
  message_text?: string;
  content?: string;
  message?: string;
  created_at: string;
  sender_id: string;
  conversation_id: string;
}

interface ActiveConvUI {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unread: number;
  otherUserId?: string;
}

// WebhookPayload interface removed: payload now sent as top-level fields

const Messages: React.FC<MessagesProps> = ({ navigateTo }) => {
  // Auth context is available if needed
  // const auth = useAuth();

  const [currentUserId, setCurrentUserId] = useState(
    localStorage.getItem('current_user_id') ||
      localStorage.getItem('public_id') ||
      localStorage.getItem('logged_in_email') ||
      localStorage.getItem('user_id') ||
      ''
  );

  const [messages, setMessages] = useState<MessageUI[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string>('');
  const [activeConv, setActiveConv] = useState<ActiveConvUI | null>(null);
  const [currentUserName, setCurrentUserName] = useState<string>('Current User');
  const [newMessage, setNewMessage] = useState<string>('');
  const [uploadingImage, setUploadingImage] = useState<boolean>(false);

  // Anchor for auto-scroll to latest message
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  // Keep a reference to current Supabase channel to clean up on conversation change
  const messagesChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  // File input ref for image uploads
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Basic check if a text looks like an image URL
  const isImageUrl = (txt: string) => {
    if (!txt) return false;
    try {
      const u = new URL(txt);
      return /\.(apng|avif|bmp|gif|heic|heif|ico|jpeg|jpg|png|svg|tif|tiff|webp)(\?.*)?$/i.test(u.pathname);
    } catch {
      return false;
    }
  };

  // Supabase Storage bucket for chat image uploads
  const STORAGE_BUCKET = 'chat-uploads';

  useEffect(() => {
    const handleStorageChange = () => {
      const newId =
        localStorage.getItem('current_user_id') ||
        localStorage.getItem('public_id') ||
        localStorage.getItem('logged_in_email') ||
        localStorage.getItem('user_id') ||
        '';
      if (newId !== currentUserId) {
        setCurrentUserId(newId);
        setMessages([]);
        setActiveConv(null);
        setActiveConversationId('');
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [currentUserId]);
  
  // Resolve identifier to UUID (same logic as messageList)
  const resolveUserId = async (identifier: string): Promise<string | null> => {
    if (!identifier) return null;
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (uuidRegex.test(identifier)) return identifier;

    const { data, error } = await supabase
      .from('users')
      .select('id')
      .or(`username.eq.${identifier},email.eq.${identifier}`)
      .maybeSingle();
    if (error || !data) return null;
    return data.id as string;
  };

  useEffect(() => {
    const resolveName = async () => {
      const uuid = await resolveUserId(currentUserId);
      if (!uuid) return;
      const { data } = await supabase
        .from('users')
        .select('full_name, username')
        .eq('id', uuid)
        .maybeSingle();
      if (data) setCurrentUserName(data.full_name || data.username || 'Current User');
    };
    resolveName();
  }, [currentUserId]);
  

  useEffect(() => {
    window.handleSelectConversation = handleSelectConversation;
    return () => {
      window.handleSelectConversation = undefined;
    };
  }, );

  // Auto-scroll to bottom whenever messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'auto' });
    }
  }, [messages]);

  // Realtime subscription to new messages for the active conversation
  useEffect(() => {
    // Cleanup previous channel
    if (messagesChannelRef.current) {
      messagesChannelRef.current.unsubscribe();
      messagesChannelRef.current = null;
    }

    if (!activeConversationId) return;

    const channel = supabase
      .channel(`messages:${activeConversationId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${activeConversationId}`,
        },
        async (payload) => {
          try {
            const row = payload.new as unknown as MessageData;
            const currentUserUuid = await resolveUserId(currentUserId);
            const ui: MessageUI = {
              id: row.id,
              text: row.message_text ?? row.message ?? row.content ?? '',
              time: new Date(row.created_at).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              }),
              sender: row.sender_id === currentUserUuid ? 'user' : 'other',
            };

            setMessages((prev) => {
              // If already present by id, do nothing
              if (prev.some((m) => m.id === ui.id)) return prev;

              // Try to replace the most recent optimistic temp message that matches
              // our own sent text to avoid flicker and duplication
              const candidateIndex = (() => {
                for (let i = prev.length - 1; i >= 0; i--) {
                  const m = prev[i];
                  if (
                    m.id.startsWith('temp-') &&
                    m.sender === 'user' &&
                    m.text === ui.text
                  ) {
                    return i;
                  }
                }
                return -1;
              })();

              if (candidateIndex !== -1) {
                const next = prev.slice();
                next[candidateIndex] = ui;
                return next;
              }

              // Otherwise, append
              return [...prev, ui];
            });
          } catch (err) {
            console.error('[realtime messages] insert handler error', err);
          }
        }
      );

    messagesChannelRef.current = channel;
    channel.subscribe((status) => {
      console.debug('[realtime messages] channel status', status);
    });

    return () => {
      channel.unsubscribe();
      if (messagesChannelRef.current === channel) {
        messagesChannelRef.current = null;
      }
    };
  }, [activeConversationId, currentUserId]);

  const fetchUserBasic = async (userId: string) => {
    const { data, error } = await supabase
      .from('users')
      .select('full_name, username')
      .eq('id', userId)
      .maybeSingle();
    if (error) throw error;
    return { name: data?.full_name || data?.username || 'Unknown User' };
  };

  const fetchLatestMessages = async (conversationId: string) => {
    try {
      const currentUserUuid = await resolveUserId(currentUserId);
      const { data, error } = await supabase
        .from('messages')
        .select('id, message_text, created_at, sender_id, conversation_id')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });
      if (error) throw error;

      // Debug: Log raw message data
      console.log('Raw message data:', data);

      // Map database messages to UI format
      const formatted: MessageUI[] = (data ?? []).map((m: MessageData) => ({
        id: m.id,
        text: m.message_text ?? '',
        time: new Date(m.created_at).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
        sender: m.sender_id === currentUserUuid ? 'user' : 'other',
      }));
      setMessages(formatted);

      if (formatted.length) {
        const last = formatted[formatted.length - 1];
        const base = isImageUrl(last.text) ? 'Sent a photo' : last.text;
        const preview = last.sender === 'user' ? `You, ${base}` : base;
        // Preserve the currently selected conversation header (name/avatar), only update preview/time
        setActiveConv((prev) => (prev ? { ...prev, lastMessage: preview, time: last.time } : prev));
      }
    } catch (e) {
      console.error('fetchLatestMessages error:', e);
    }
  };

  const ensureConversationWith = async (otherUserId: string) => {
    const currentUserUuid = await resolveUserId(currentUserId);
    if (!currentUserUuid) throw new Error('Current user not resolved');
    const { data: existing, error: findErr } = await supabase
      .from('conversations')
      .select('conversation_id, participant1_id, participant2_id')
      .or(
        `and(participant1_id.eq.${currentUserUuid},participant2_id.eq.${otherUserId}),and(participant1_id.eq.${otherUserId},participant2_id.eq.${currentUserUuid})`
      )
      .maybeSingle();

    if (findErr && findErr.code !== 'PGRST116') {
      throw findErr;
    }

    if (existing?.conversation_id) {
      return { conversationId: existing.conversation_id, created: false };
    }

    const { data: inserted, error: insErr } = await supabase
      .from('conversations')
      .insert({ participant1_id: currentUserUuid, participant2_id: otherUserId })
      .select('conversation_id')
      .single();

    if (insErr) throw insErr;
    return { conversationId: inserted.conversation_id, created: true };
  };

  const handleSelectConversation = async (id: string, passedName?: string, passedOtherUserId?: string) => {
    try {
      let conversationId: string | null = id || null;
      let otherUserId: string | null = passedOtherUserId || null;

      const currentUserUuid = await resolveUserId(currentUserId);
      if (!currentUserUuid) return;

      // If we don't have otherUserId yet, fetch minimal conversation info
      if (!otherUserId) {
        const { data: convById } = await supabase
          .from('conversations')
          .select('conversation_id, participant1_id, participant2_id')
          .eq('conversation_id', id)
          .maybeSingle();

        if (convById?.conversation_id) {
          conversationId = convById.conversation_id;
          otherUserId =
            convById.participant1_id === currentUserUuid
              ? convById.participant2_id
              : convById.participant1_id;
        }
      }

      if (!conversationId || !otherUserId) return;

      // Use passed name immediately for instant header; if it's missing or placeholder, fetch now
      let resolvedName = passedName;
      if (!resolvedName || resolvedName === 'Loading...' || resolvedName === 'Unknown User') {
        const { name } = await fetchUserBasic(otherUserId);
        resolvedName = name;
      }

      setActiveConversationId(conversationId);
      setActiveConv({
        id: conversationId,
        otherUserId,
        name: resolvedName || 'Unknown User',
        avatar: '',
        lastMessage: 'Loading messages...',
        time: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
        unread: 0,
      });

      await fetchLatestMessages(conversationId);
    } catch (err) {
      console.error('Error in handleSelectConversation:', err);
    }
  };

  const sendWebhookMessage = async (messageText: string) => {
    try {
      if (!activeConv || !activeConv.otherUserId) return;

      const currentUserUuid = await resolveUserId(currentUserId);
      if (!currentUserUuid) return;

      // Match expected schema: top-level fields
      const payload = {
        message: messageText,
        sender_id: currentUserUuid,
        sender_name: currentUserName,
        receiver_id: activeConv.otherUserId,
        receiver_name: activeConv.name,
        conversation_id: activeConversationId,
        image_url: messageText,
      };

      console.debug('[sendWebhookMessage] URL and payload', {
        url: 'https://primary-production-6722.up.railway.app/webhook/dd88723f-330f-48e7-9818-4f578f952def',
        payload,
      });
      const response = await fetch(
        'https://primary-production-6722.up.railway.app/webhook/dd88723f-330f-48e7-9818-4f578f952def',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
          },
          body: JSON.stringify(payload),
        }
      );

      if (!response.ok) {
        const text = await response.text().catch(() => '');
        console.error('[sendWebhookMessage] non-OK response', response.status, text);
        throw new Error(`Failed: ${response.status}`);
      }
      const data = await response.json().catch(() => ({}));
      console.debug('[sendWebhookMessage] success', data);

      const cid = data.conversation_id || activeConversationId;
      if (cid && cid !== activeConversationId) {
        setActiveConversationId(cid);
      }
      // Do not fetch here to avoid flicker; rely on realtime INSERT to update the list
    } catch (e) {
      console.error('sendWebhookMessage error:', e);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const sendMessage = async () => {
    const trimmed = newMessage.trim();
    if (!trimmed) return;

    const nowStr = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });
    const temp: MessageUI = {
      id: `temp-${Date.now()}`,
      text: trimmed,
      time: nowStr,
      sender: 'user',
    };

    console.debug('[sendMessage] start', {
      hasActiveConv: !!activeConv,
      activeConversationId,
      otherUserId: activeConv?.otherUserId,
    });
    setMessages((prev) => [...prev, temp]);
    if (activeConv)
      setActiveConv({ ...activeConv, lastMessage: `You, ${trimmed}`, time: 'Just now' });

    setNewMessage('');

    if (activeConv?.otherUserId && !activeConversationId) {
      const ensured = await ensureConversationWith(activeConv.otherUserId);
      if (ensured.conversationId !== activeConversationId) {
        setActiveConversationId(ensured.conversationId);
      }
    }

    console.debug('[sendMessage] calling webhook');
    await sendWebhookMessage(trimmed);
  };

  // Open file picker when clicking the attach button
  const handleAttachClick = () => {
    if (fileInputRef.current) fileInputRef.current.click();
  };

  // Image upload handler
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Reset the input so the same file can be selected again next time
    e.target.value = '';

    try {
      if (!activeConv || !activeConv.otherUserId) return;
      const currentUserUuid = await resolveUserId(currentUserId);
      if (!currentUserUuid) return;

      // Ensure conversation exists before upload (so preview updates go to correct thread)
      if (!activeConversationId) {
        const ensured = await ensureConversationWith(activeConv.otherUserId);
        if (ensured.conversationId !== activeConversationId) {
          setActiveConversationId(ensured.conversationId);
        }
      }

      setUploadingImage(true);
      const bucket = STORAGE_BUCKET;
      const timestamp = Date.now();
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const path = `${currentUserUuid}/${timestamp}_${safeName}`;

      const { error: upErr } = await supabase.storage
        .from(bucket)
        .upload(path, file, { upsert: false, cacheControl: '3600', contentType: file.type });
      if (upErr) throw upErr;

      const { data: pub } = supabase.storage.from(bucket).getPublicUrl(path);
      const publicUrl = pub.publicUrl;

      // Optimistic UI with image
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const tempImg: MessageUI = {
        id: `temp-${Date.now()}`,
        text: publicUrl,
        time: nowStr,
        sender: 'user',
      };
      setMessages((prev) => [...prev, tempImg]);
      if (activeConv)
        setActiveConv({ ...activeConv, lastMessage: 'You, Sent a photo', time: 'Just now' });

      // Send webhook with the image URL as the message text so receiver gets it
      await sendWebhookMessage(publicUrl);
    } catch (err: unknown) {
      console.error('[upload image] error', err);
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.toLowerCase().includes('bucket') && msg.toLowerCase().includes('not found')) {
        alert(
          `Image upload bucket not found.\n\n` +
          `Please create a public Supabase Storage bucket named "${STORAGE_BUCKET}" and try again.\n` +
          `Supabase Dashboard -> Storage -> Create bucket -> Name: ${STORAGE_BUCKET} -> Public.`
        );
      }
    } finally {
      setUploadingImage(false);
    }
  };

  return (
    <div className="messages-page min-h-screen bg-[#141825] scroll-smooth overflow-x-hidden">
      {/* Header */}
      <header className="bg-[#141825] shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14 sm:h-16">
            <div
              className="flex items-center cursor-pointer"
              onClick={() => navigateTo('main')}
            >
              <span className="text-lg sm:text-xl font-bold text-white">Messages</span>
            </div>
            <button
              onClick={() => navigateTo('main')}
              className="text-sm sm:text-base text-gray-300 hover:text-primary transition-colors duration-150"
            >
              Back to Home
            </button>
          </div>
        </div>
      </header>
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-0 sm:px-0 md:px-0 lg:px-0 py-0">
        <div
          className="messenger-pane flex flex-col md:flex-row overflow-hidden transition-shadow duration-200"
          style={{ height: 'calc(100vh - 64px)', maxHeight: 'calc(100vh - 64px)' }}
        >
          {/* Sidebar */}
          <aside className="w-full md:w-1/3 lg:w-1/4 border-b md:border-b-0 md:border-r border-[#2a2a34] flex-shrink-0 md:max-h-full overflow-hidden bg-[#141825]">
            <div className="p-3 border-b border-[#2a2a34]">
              <h2 className="text-sm font-semibold text-white tracking-wide">Conversations</h2>
            </div>
            <MessageList
              onSelectConversation={handleSelectConversation}
              selectedConversationId={activeConversationId}
            />
          </aside>

          {/* Chat Area */}
          <section className="flex-1 flex flex-col bg-[#141825] overflow-hidden">
            {/* Chat Header */}
            <div className="chat-header p-3 border-b border-[#2a2a34] flex items-center justify-between">
              <div className="flex items-center">
                <div className="mr-3">
                  {activeConv?.avatar ? (
                    <img
                      src={activeConv.avatar}
                      alt={activeConv?.name}
                      className="h-9 w-9 rounded-full object-cover transition-transform duration-200 motion-safe:hover:scale-105 avatar-frame"
                    />
                  ) : (
                    <div className="h-9 w-9 rounded-full bg-gray-700 flex items-center justify-center avatar-frame">
                      <User className="h-5 w-5 text-gray-300" />
                    </div>
                  )}
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-medium text-white">
                    {activeConv?.name || 'Select a chat'}
                  </h3>
                </div>
              </div>
              <button className="text-gray-300 hover:text-white transition-colors duration-150">
                <MoreVertical className="h-5 w-5" />
              </button>
            </div>

            {/* Chat Messages */}
            <div
              className="chat-surface flex-1 p-2 sm:p-4 overflow-y-auto no-anim scroll-smooth"
              style={{ height: 'calc(100vh - 180px)', maxHeight: 'calc(100vh - 180px)' }}
            >
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`mb-4 flex ${
                    message.sender === 'user' ? 'justify-end' : 'justify-start'
                  } animate-slide-fade`}
                >
                  {message.sender === 'other' && (
                    <div className="mr-2">
                      {activeConv?.avatar ? (
                        <img
                          src={activeConv.avatar}
                          alt={activeConv?.name}
                          className="h-8 w-8 rounded-full object-cover transition-transform duration-200 motion-safe:hover:scale-105 avatar-frame"
                        />
                      ) : (
                        <div className="h-8 w-8 rounded-full bg-gray-700 flex items-center justify-center avatar-frame">
                          <User className="h-4 w-4 text-gray-300" />
                        </div>
                      )}
                    </div>
                  )}

                  <div
                    className={[
                      "bubble max-w-[85%] xs:max-w-[90%] sm:max-w-[75%] md:max-w-[58ch] px-2 xs:px-3 sm:px-4 py-1 xs:py-2 transition-all duration-200 will-change-transform",
                      message.sender === 'user'
                        ? "bubble--me bg-primary text-white"
                        : "bubble--other bg-gray-700 text-gray-100"
                    ].join(" ")}
                  >
                    {isImageUrl(message.text) ? (
                      <a href={message.text} target="_blank" rel="noreferrer">
                        <img
                          src={message.text}
                          alt="sent image"
                          className="max-h-32 xs:max-h-40 sm:max-h-56 md:max-h-64 max-w-full rounded-md mb-1 transition-transform duration-200 motion-safe:hover:scale-[1.01]"
                        />
                      </a>
                    ) : (
                      <p className="text-xs xs:text-sm break-words whitespace-pre-wrap">{message.text}</p>
                    )}
                    <span className="time-chip">{message.time}</span>
                  </div>
                </div>
              ))}

              {/* Auto-scroll anchor */}
              <div ref={messagesEndRef} />

              {!messages.length && (
                <div className="h-full w-full flex items-center justify-center text-sm text-gray-400">
                  {activeConv ? 'No messages yet. Say hi!' : 'Select a conversation'}
                </div>
              )}
            </div>

            {/* Composer */}
            <div className="composer p-2 sm:p-3 md:p-4 border-t border-[#2a2a34]">
              <div className="flex items-center">
                <button
                  className="icon-btn mr-2 text-gray-300 hover:text-white bg-[#1e2235] ring-1 ring-[rgba(255,61,110,.25)]"
                  onClick={handleAttachClick}
                  disabled={!activeConv || uploadingImage}
                  title={uploadingImage ? 'Uploading…' : 'Attach image'}
                >
                  <Paperclip className="h-5 w-5" />
                </button>

                <div className="flex-1 relative">
                  <textarea
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type a message…"
                    className="input-glass w-full pl-4 pr-10 py-2 text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none transition-shadow duration-150 shadow-sm focus:shadow bg-[#1e2235] text-white"
                    rows={1}
                  />
                  <button
                    className="absolute right-2 xs:right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200 transition-colors duration-150"
                    aria-label="Emoji"
                  >
                    <Smile className="h-4 w-4 xs:h-5 xs:w-5" />
                  </button>
                </div>

                <button
                  onClick={sendMessage}
                  className="icon-btn ml-2 bg-primary text-white hover:bg-primary-dark"
                  disabled={!newMessage.trim() || !activeConv || uploadingImage}
                  aria-label="Send"
                >
                  <Send className="h-4 w-4 xs:h-5 xs:w-5" />
                </button>

                {/* Hidden file input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Messages;
